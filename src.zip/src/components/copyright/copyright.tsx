import { makeStyles, Typography } from '@material-ui/core'
import { Link } from 'react-router-dom'

const styles = makeStyles(() => ({
  link: {
    textDecoration: 'none',
    fontWeight: 'bold',
    color: 'white',
  },
}))

export const Copyright: React.FC<any> = () => {
  const classNames = styles()
  return (
    <Typography variant='body2' color='textSecondary' align='center'>
      {'Machine Learning: '}
      <Link className={classNames.link} to='/'>
       Movie Recommendation System
      </Link>{' '}
      {new Date().getFullYear()}
      {<br></br>}
      {'Professor: '} 
      <Link className={classNames.link} to='/'>
      Dr. Emdad Khan
      </Link>{' '}
      {<br></br>}
      {'Student:  '}
      <Link className={classNames.link} to='/'>
        Duy Hanh Nguyen, Duy Thai Nguyen, Duc Phuoc Doan, Lien Thanh Le
      </Link>{' '}
      {'.'}
    </Typography>
  )
}
