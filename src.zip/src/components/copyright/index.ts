import { Copyright } from './copyright'

export default Copyright
