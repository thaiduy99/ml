import { Carousel } from './carousel'

export default Carousel
