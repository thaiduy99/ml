import { MovieDetail } from './movie-detail'

export default MovieDetail
